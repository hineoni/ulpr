﻿Console.Write($"Введите фунты и дюймы #1: ");
int m1 = Convert.ToInt32(Console.ReadLine());
int m3 = Convert.ToInt32(Console.ReadLine());
IMer moneyBag1 = new EngMer(funt: m1, inch: m3);
Console.Write($"Введите фунты и дюймы #2: ");
int m2 = Convert.ToInt32(Console.ReadLine());
int m4 = Convert.ToInt32(Console.ReadLine());
IMer moneyBag2 = new EngMer(funt: m2, inch: m4);
Console.Write("Введите число для операций: ");
int k = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("\nСложение.");
moneyBag1.plus(moneyBag2);
Console.WriteLine("\nВычитание.");
moneyBag1.minus(moneyBag2);
Console.WriteLine("\nУмножение первой суммы на число.");
moneyBag1.times(k);
Console.WriteLine("\nУмножение второй суммы на число.");
moneyBag2.times(k);
Console.WriteLine("\nДеление первой суммы на число.");
moneyBag1.divide(k);
Console.WriteLine("\nДеление второй суммы на число.");
moneyBag2.divide(k);
Console.WriteLine("\nСравнение сумм.");
moneyBag1.compare(moneyBag2);

interface IMer
{
    void getTotal();
    double total();
    void merge();
    void plus(IMer bag);
    void minus(IMer bag);
    void times(int n);
    void divide(int n);
    void compare(IMer bag);
}
abstract class Mer : IMer
{
    public Mer()
    {
        totalvalue = 0;
    }
    public double totalvalue;
    public abstract void getTotal();
    public abstract double total();
    public abstract void merge();
    public abstract void plus(IMer bag);
    public abstract void minus(IMer bag);
    public abstract void times(int n);
    public abstract void divide(int n);
    public abstract void compare(IMer bag);
}
class EngMer : Mer
{
    private double funt;
    private double inch;
    public EngMer() :
        base()
    {
        funt = 0;
        inch = 0;
    }
    public EngMer(double funt, double inch) :
        base()
    {
        this.funt = funt;
        this.inch = inch;
    }
    public override void getTotal()
    {
        merge();
        string output = "";
        if (funt != 0)
        {
            output += $"{funt} фунтов ";
        }
        if (inch != 0)
        {
            output += $"{inch} дюймов ";
        }
        Console.WriteLine($"Всего содержится {total()} дюймов. {output}");
    }
    public override double total()
    {
        return funt * 12 + inch;
    }
    public override void merge()
    {
        while (inch >= 12)
        {
            inch -= 12;
            funt++;
        }
    }
    public override void plus(IMer bag)
    {
        EngMer bagSum = new EngMer();
        double totalvalue1 = funt * 12 + inch;
        double totalvalue2 = bag.total();
        bagSum = new(0, totalvalue1 + totalvalue2);
        bagSum.merge();
        bagSum.getTotal();
    }
    public override void minus(IMer bag)
    {
        double totalvalue1 = funt * 12 + inch;
        double totalvalue2 = bag.total();
        EngMer bagSum = new(0, Math.Abs(totalvalue1 - totalvalue2));
        bagSum.merge();
        bagSum.getTotal();
    }
    public override void times(int n)
    {
        int newtotal = Convert.ToInt32(total()) * n;
        EngMer BAG = new EngMer(0, newtotal);
        BAG.getTotal();
    }
    public override void divide(int n)
    {
        int newtotal = Convert.ToInt32(total()) / n;
        EngMer BAG = new EngMer(0, newtotal);
        BAG.getTotal();
    }
    public override void compare(IMer bag)
    {
        if (total() > bag.total())
        {
            Console.WriteLine("Сумма 1 больше.");
        }
        if (total() < bag.total())
        {
            Console.WriteLine("Сумма 2 больше.");
        }
        if (total() == bag.total())
        {
            Console.WriteLine("Суммы одинаковые.");
        }
    }
}