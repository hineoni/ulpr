﻿Console.WriteLine("Формат записи: 54521 --- Численно равно 545,21 [руб.]");
Console.Write($"Введите сумму #1: ");
int num1 = Convert.ToInt32(Console.ReadLine());
IMoney Amount1 = new RuMoney(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, num1);
Console.Write($"Введите сумму #2: ");
int num2 = Convert.ToInt32(Console.ReadLine());
IMoney Amount2 = new RuMoney(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, num2);
Console.Write("Введите число для операций: ");
int k = Convert.ToInt32(Console.ReadLine());
Console.WriteLine();
Console.Write("Сложение сумм: ");
Amount1.Plus(Amount2);
Console.Write("Вычитание сумм: ");
Amount1.Minus(Amount2);
Console.Write("Умножение первой суммы на число: ");
Amount1.TimesBy(k);
Console.Write("Умножение второй суммы на число: ");
Amount2.TimesBy(k);
Console.Write("Деление первой суммы на число: ");
Amount1.DivideBy(k);
Console.Write("Деление второй суммы на число: ");
Amount2.DivideBy(k);
Console.Write("Сравнение сумм: ");
Amount1.Compare(Amount2);

interface IMoney
{
    void MoneyNominals();
    int Total();
    void Merge();
    void Plus(IMoney ASum);
    void Minus(IMoney ASum);
    void TimesBy(int k);
    void DivideBy(int k);
    void Compare(IMoney ASum);
}
abstract class Money : IMoney
{
    public abstract void MoneyNominals();
    public abstract int Total();
    public abstract void Merge();
    public abstract void Plus(IMoney ASum);
    public abstract void Minus(IMoney ASum);
    public abstract void TimesBy(int k);
    public abstract void DivideBy(int k);
    public abstract void Compare(IMoney ASum);
}
class RuMoney: Money
{
    private int rub5000;
    private int rub1000;
    private int rub500;
    private int rub100;
    private int rub50;
    private int rub10;
    private int rub5;
    private int rub2;
    private int rub1;
    private int kop50;
    private int kop10;
    private int kop5;
    private int kop1;
    public RuMoney() :
        base()
    {
        rub5000 = 0;
        rub1000 = 0;
        rub500 = 0;
        rub100 = 0;
        rub50 = 0;
        rub10 = 0;
        rub5 = 0;
        rub2 = 0;
        rub1 = 0;
        kop50 = 0;
        kop10 = 0;
        kop5 = 0;
        kop1 = 0;
    }
    public RuMoney(int rub5000, int rub1000, int rub500, int rub100, int rub50, int rub10, int rub5, 
        int rub2, int rub1, int kop50, int kop10, int kop5, int kop1):
        base()
    {
        this.rub5000 = rub5000;
        this.rub1000 = rub1000;
        this.rub500 = rub500;
        this.rub100 = rub100;
        this.rub50 = rub50;
        this.rub10 = rub10;
        this.rub5 = rub5;
        this.rub2 = rub2;
        this.rub1 = rub1;
        this.kop50 = kop50;
        this.kop10 = kop10;
        this.kop5 = kop5;
        this.kop1 = kop1;
    }
    public override void MoneyNominals()
    {
        Merge();
        string output = "";
        if (rub5000 != 0)
        {
            output += $"{rub5000} * купюр номиналом 5000 [руб.]\n";
        }
        if (rub1000 != 0)
        {
            output += $"{rub1000} * купюр номиналом 1000 [руб.]\n";
        }
        if (rub500 != 0)
        {
            output += $"{rub500} * купюр номиналом 500 [руб.]\n";
        }
        if (rub100 != 0)
        {
            output += $"{rub100} * купюр номиналом 100 [руб.]\n";
        }
        if (rub50 != 0)
        {
            output += $"{rub50} * купюр номиналом 50 [руб.]\n";
        }
        if (rub10 != 0)
        {
            output += $"{rub10} * монет номиналом 10 [руб.]\n";
        }
        if (rub5 != 0)
        {
            output += $"{rub5} * монет номиналом 5 [руб.]\n";
        }
        if (rub2 != 0)
        {
            output += $"{rub2} * монет номиналом 2 [руб.]\n";
        }
        if (rub1 != 0)
        {
            output += $"{rub1} * монет номиналом 1 [руб.]\n";
        }
        if (kop50 != 0)
        {
            output += $"{kop50} * монет номиналом 50 [коп.]\n";
        }
        if (kop10 != 0)
        {
            output += $"{kop10} * монет номиналом 10 [коп.]\n";
        }
        if (kop5 != 0)
        {
            output += $"{kop5} * монет номиналом 5 [коп.]\n";
        }
        if (kop1 != 0)
        {
            output += $"{kop1} * монет номиналом 1 [коп.]\n";
        }
        string Part1 = Convert.ToString(Total()).Substring(0, Convert.ToString(Total()).Length-2);
        string Part2 = Convert.ToString(Total()).Substring(Part1.Length);
        string NewTotal = Part1 + "," + Part2;
        Console.WriteLine($"Всего содержится {Total()} Копеек = {NewTotal} [руб.]\n{output}");
    }
    public override int Total()
    {
        return rub5000*500000+rub1000*100000+rub500*50000+rub100*10000+
            rub50*5000+rub10*1000+rub5*500+rub2*200+rub1*100+kop50*50+kop10*10+kop5*5+kop1*1;
    }
    public override void Merge()
    {
        while (kop1 >= 5)
        {
            kop1 -= 5;
            kop5++;
        }
        while (kop5 >= 2) 
        { 
            kop5 -= 2;
            kop10++;
        }
        while (kop10 >= 5)
        {
            kop10 -= 5;
            kop50++;
        }
        while (kop50 >= 2)
        {
            kop50 -= 2;
            rub1++;
        }
        mergeOtkat:
        while (rub1 >= 2)
        {
            rub1 -= 2;
            rub2++;
        }
        while (rub2 >= 3)
        {
            rub2 -= 3;
            rub5++;
            rub1++;
            goto mergeOtkat;
        }
        while (rub5 >= 2)
        {
            rub5 -= 2;
            rub10++;
        }
        while (rub10 >= 5)
        {
            rub10 -= 5;
            rub50++;
        }
        while (rub50 >= 2)
        {
            rub50 -= 2;
            rub100++;
        }
        while (rub100 >= 5)
        {
            rub100 -= 5;
            rub500++;
        }
        while (rub500 >= 2)
        {
            rub500 -= 2;
            rub1000++;
        }
        while (rub1000 >= 5)
        {
            rub1000 -= 5;
            rub5000++;
        }
    }
    public override void Plus(IMoney ASum)
    {
        int amount1 = rub5000 * 500000 + rub1000 * 100000 + rub500 * 50000 + rub100 * 10000 +
            rub50 * 5000 + rub10 * 1000 + rub5 * 500 + rub2 * 200 + rub1 + kop50 * 50 + kop10 * 10 + kop5 * 5 + kop1 * 1;
        int amount2 = ASum.Total();
        RuMoney sum = new RuMoney(0,0,0,0,0,0,0,0,0,0,0,0, amount1+amount2);
        sum.Merge();
        sum.MoneyNominals();
    }
    public override void Minus(IMoney ASum)
    {
        int amount1 = rub5000 * 500000 + rub1000 * 100000 + rub500 * 50000 + rub100 * 10000 +
            rub50 * 5000 + rub10 * 1000 + rub5 * 500 + rub2 * 200 + rub1 + kop50 * 50 + kop10 * 10 + kop5 * 5 + kop1 * 1;
        int amount2 = ASum.Total();
        RuMoney sum = new RuMoney(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Math.Abs(amount1 - amount2));
        sum.Merge();
        sum.MoneyNominals();
    }
    public override void TimesBy(int k)
    {
        int NewAmount = Total() * k;
        RuMoney sum = new RuMoney(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NewAmount);
        sum.Merge();
        sum.MoneyNominals();
    }
    public override void DivideBy(int k)
    {
        int NewAmount = Total() / k;
        RuMoney sum = new RuMoney(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NewAmount);
        sum.Merge();
        sum.MoneyNominals();
    }
    public override void Compare(IMoney ASum)
    {
        if (Total() > ASum.Total())
        {
            Console.WriteLine("Сумма 1 содержит больше денег.");
        }
        if (Total() < ASum.Total())
        {
            Console.WriteLine("Сумма 2 содержит больше денег.");
        }
        if (Total() == ASum.Total())
        {
            Console.WriteLine("Суммы содержат одинаковое количество денег.");
        }
    }
}