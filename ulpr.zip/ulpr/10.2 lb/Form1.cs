﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10._2_lb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        double res1 = 0;
        double res2 = 0;
        double result = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            res1 = Convert.ToInt32(((TextBox)sender).Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            res2 = Convert.ToInt32(((TextBox)sender).Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                result = res1 + res2;
            }
            else if (radioButton2.Checked == true)
            {
                result = (res1 * res2) / (res1 + res2);
            }
            else
            {
                result = 0;
            }
            textBox3.Text = result.ToString();
        }
    }
}
