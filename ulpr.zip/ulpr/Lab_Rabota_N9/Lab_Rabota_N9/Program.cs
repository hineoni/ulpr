﻿List<IAnimals> some = [];
Cow cow = new Cow();
Horse horse = new Horse();
Dog dog = new Dog();
Cat cat = new Cat();
cow.Info();
cow.Talk();
horse.Info();
horse.Talk();
dog.Info();
dog.Talk();
cat.Info();
cat.Talk();

interface IAnimals
{
    public virtual void Talk() { }
    public virtual void Info() { }
}
abstract class Animals : IAnimals
{
    public Random Rand = new Random();
    public Int32 Mass;
    public Int32 Height;
    public string Speak;
    public string Specie;
    public virtual void Talk()
    {
        Console.WriteLine($"Животное {Specie} говорит: {Speak}");
    }
    public virtual void Info()
    {
        Console.WriteLine($"\nВид: {Specie}. Масса: {Mass} кг. Рост {Height} см.");
    }
}
abstract class Artiodactyl : Animals
{
    public override void Talk()
    {
        Console.WriteLine($"Парнокопытное {Specie} говорит: {Speak}");
    }
}
class Cow : Artiodactyl
{
    public Cow() : base()
    {
        Mass = Rand.Next(300, 501);
        Height = Rand.Next(130, 170);
        Speak = "Му-у";
        Specie = "Корова";
    }
}
class Horse : Artiodactyl
{
    public Horse() : base()
    {
        Mass = Rand.Next(400, 701);
        Height = Rand.Next(170, 250);
        Speak = "И-го-го";
        Specie = "Лошадь";
    }
}
class Dog : Animals
{
    public Dog() : base()
    {
        Mass = Rand.Next(3, 7);
        Height = Rand.Next(25, 60);
        Speak = "Гав-гав";
        Specie = "Собака";
    }
}
class Cat : Animals
{
    public Cat() : base()
    {
        Mass = Rand.Next(1, 5);
        Height = Rand.Next(20, 35);
        Speak = "Мяу";
        Specie = "Кошка";
    }
}