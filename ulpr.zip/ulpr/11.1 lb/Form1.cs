﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11._1_lb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int n = 0;
        int result1 = 0;
        int result2 = 0;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            n = Convert.ToInt32(textBox1.Text);
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            textBox1.Text = hScrollBar1.Value.ToString();
            hScrollBar1.Value = (int)n;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int w = 0;
            while (n > w)
            {
                result1 += w;
                w += 1;
            }
            result2 = (n * (n - 1)) / 2;
            textBox2.Text = result1.ToString();
            textBox3.Text = result2.ToString();
        }
    }
}
