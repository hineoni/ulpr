﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _10._1_lb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;
        }
        double result = 0;
        double resistanse = 0;
        double voltage = 0;

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            resistanse = Convert.ToDouble(textBox2.Text);
            if (textBox2.Text != null)
            {
                button1.Enabled = true;
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            voltage = Convert.ToDouble(textBox1.Text);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            result = voltage / resistanse;
            textBox3.Text = result.ToString();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
